import {EventBus} from 'primevue/utils';

export default EventBus();